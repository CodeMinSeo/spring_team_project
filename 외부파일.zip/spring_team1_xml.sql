SELECT * FROM java503_team1.review_board;

-- 특정 유저가 작성한 리뷰 조회 
SELECT * FROM review_board WHERE user_id = 'test1' AND deleted_yn = 'N';

-- 특정 유저의 리뷰 삭제 
UPDATE review_board SET deleted_yn = 'Y' WHERE review_idx = 19;

SELECT * FROM java503_team1.user;

-- 더미 ID 생성 
INSERT INTO user (user_id, user_pw, user_name, user_email, create_date)
VALUES ('test2', '1234', '테스터2', 'test02@bitc.ac.kr', now()),
('test3', '1234', '테스터3', 'test03@bitc.ac.kr', now()),
('test4', '1234', '테스터4', 'test04@bitc.ac.kr', now()),
('test5', '1234', '테스터5', 'test05@bitc.ac.kr', now()),
('test6', '1234', '테스터6', 'test06@bitc.ac.kr', now()),
('test7', '1234', '테스터7', 'test07@bitc.ac.kr', now()),
('test8', '1234', '테스터8', 'test08@bitc.ac.kr', now()),
('test9', '1234', '테스터9', 'test09@bitc.ac.kr', now()),
('test10', '1234', '테스터10', 'test010@bitc.ac.kr', now());

-- 관리자 ID 생성 
INSERT INTO user (user_id, user_pw, user_name, user_email, create_date, grade)
VALUES ('A', '1234', 'A', 'A@bitc.ac.kr', now(), 'A');

-- 유저 ID 생성 
INSERT INTO user (user_id, user_pw, user_name, user_email, create_date)
VALUES ('12345', '12345', '유저1', 'A@bitc.ac.kr', now());

-- 유저 삭제
DELETE FROM user WHERE user_id = 'A';

-- 로그인한 유저의 마이페이지에 자신의 리뷰 게시 
SELECT a.review_idx, a.user_id, a.UC_SEQ, a.UC_SEQ2, a.contents, a.scope,
DATE_FORMAT(a.create_date, '%Y-%m-%d') as create_date, substring(b.image_url,24,100) as image_url
FROM review_board a
LEFT JOIN review_image b
ON a.review_idx = b.review_idx
where a.user_id = 'test1'
ORDER BY create_date ASC;
    

-- 평균 평점이 같은 경우, 리뷰 개수 기준 정렬
SELECT s.*, COUNT(r.review_idx) AS review_count
FROM spot s
JOIN review_board r ON s.UC_SEQ = r.UC_SEQ
GROUP BY s.UC_SEQ
ORDER BY SCOPE_AVG DESC, review_count DESC
LIMIT 1;

-- 리뷰 많은 순으로 맛집 10개 조회
SELECT p.*, COUNT(r.review_idx) AS review_count
FROM place p
LEFT JOIN review_board r ON p.UC_SEQ = r.UC_SEQ2
GROUP BY p.UC_SEQ, p.MAIN_TITLE
ORDER BY review_count DESC
LIMIT 10;

-- 맛집에 더미 리뷰 추가 
insert review_board (user_id, UC_SEQ2, contents, scope, create_date)
value ('test1', 70, '사장님이 친절하고 음식이 맛있어요', 4, now()),
('test2', 72, '사장님이 친절하고 음식이 맛있어요', 4, now()),
('test3', 72, '사장님이 친절하고 음식이 맛있어요', 3, now()),
('test4', 77, '사장님이 친절하고 음식이 맛있어요', 2, now()),
('test5', 83, '사장님이 친절하고 음식이 맛있어요', 1, now());


-- 특정 유저 정보 가져오기 
SELECT *
FROM user
WHERE user_id = 'test1'
AND deleted_yn = 'N'
ORDER BY create_date ASC;

-- 리뷰 넣기
INSERT INTO review_board (user_id, UC_SEQ, contents, scope, create_date)
VALUES ('admin', 256, '맛있어요', 5, now());

-- 북마크 추가
INSERT INTO bookmark (user_id, spot_ucseq, create_date)
VALUES ('test3', 255, now());

-- 관리자 ID 추가
INSERT INTO user (user_id, user_pw, user_name, user_email, create_date, grade)
VALUES ('admin', 'admin', '관리자', 'admin@naver.com', now(), 'A');

-- 유저 수정
UPDATE user
SET user_pw = '12345', update_date = now()
WHERE user_id = 'test1';

-- 유저삭제
UPDATE user
SET deleted_yn = 'Y'
WHERE user_id = 'test1';

UPDATE user
SET update_date = now(),  deleted_yn = 'N'
WHERE user_id = 'test1';

DELETE 
FROM user 
WHERE user_id = 'test1';

-- 특정 리뷰 조회(이미지 포함)
SELECT a.review_idx, a.user_id, a.UC_SEQ, a.UC_SEQ2, a.contents, a.scope,
DATE_FORMAT(a.create_date, '%Y-%m-%d') as create_date, substring(b.image_url,24,100) as image_url
FROM review_board a
LEFT JOIN review_image b
ON a.review_idx = b.review_idx
where a.review_idx = 100
AND a.deleted_yn = 'N';

-- 리뷰에 있는 별점의 평균을 해당 명소의 컬럼속성에 평점을 넣고 가장 높은 하나의 명소를 셀랙(평점이 같다면 리뷰수 기순)
SELECT s.*, COUNT(r.review_idx) AS review_count
FROM spot s
JOIN review_board r ON s.UC_SEQ = r.UC_SEQ
GROUP BY s.UC_SEQ
ORDER BY SCOPE_AVG DESC, review_count DESC
LIMIT 1;